using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace KisiselNotDefterim;

public class NotVerisi
{
    public string Baslik { get; set; } = "";
    public string Icerik { get; set; } = "";
    public List<string> EkliDosyalar { get; set; } = new();
}

public partial class MainWindow : Window
{
    private readonly string _anaKlasor;
    private readonly string _eklerKlasoru;
    private NotVerisi _aktifNot = new();

    public MainWindow()
    {
        InitializeComponent();

        _anaKlasor = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "KisiselNotlarim");
        _eklerKlasoru = Path.Combine(_anaKlasor, "Ekler");
        Directory.CreateDirectory(_anaKlasor);
        Directory.CreateDirectory(_eklerKlasoru);

        NotListesiniYenile();
    }

    private void NotListesiniYenile()
    {
        var dosyalar = Directory.GetFiles(_anaKlasor, "*.json")
                                .Select(Path.GetFileNameWithoutExtension)
                                .ToList();
        NotlarListesi.ItemsSource = dosyalar;
    }

    private void YeniNot_Click(object? sender, RoutedEventArgs e)
    {
        _aktifNot = new NotVerisi();
        BaslikKutusu.Text = "";
        IcerikKutusu.Text = "";
        EklerListesi.ItemsSource = null;
        NotlarListesi.SelectedItem = null;
    }

    private void Kaydet_Click(object? sender, RoutedEventArgs e)
    {
        string baslik = BaslikKutusu.Text?.Trim() ?? "";
        if (string.IsNullOrEmpty(baslik))
            baslik = $"Not_{DateTime.Now:yyyyMMdd_HHmmss}";

        foreach (char c in Path.GetInvalidFileNameChars())
            baslik = baslik.Replace(c, '_');

        _aktifNot.Baslik = baslik;
        _aktifNot.Icerik = IcerikKutusu.Text ?? "";

        string jsonYolu = Path.Combine(_anaKlasor, $"{baslik}.json");
        string jsonMetni = JsonSerializer.Serialize(_aktifNot, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(jsonYolu, jsonMetni);

        BaslikKutusu.Text = baslik;
        NotListesiniYenile();
    }

    // Sol listeden seçili notu diskten ve listeden siler
    private void NotSil_Click(object? sender, RoutedEventArgs e)
    {
        if (NotlarListesi.SelectedItem is not string seciliBaslik) return;

        string jsonYolu = Path.Combine(_anaKlasor, $"{seciliBaslik}.json");
        if (File.Exists(jsonYolu))
        {
            File.Delete(jsonYolu);
        }

        YeniNot_Click(null, new RoutedEventArgs());
        NotListesiniYenile();
    }

    private void NotSecildi_Changed(object? sender, SelectionChangedEventArgs e)
    {
        if (NotlarListesi.SelectedItem is not string seciliBaslik) return;

        string jsonYolu = Path.Combine(_anaKlasor, $"{seciliBaslik}.json");
        if (!File.Exists(jsonYolu)) return;

        string jsonMetni = File.ReadAllText(jsonYolu);
        _aktifNot = JsonSerializer.Deserialize<NotVerisi>(jsonMetni) ?? new NotVerisi();

        BaslikKutusu.Text = _aktifNot.Baslik;
        IcerikKutusu.Text = _aktifNot.Icerik;
        EklerListesi.ItemsSource = _aktifNot.EkliDosyalar.ToList();
    }

    private async void DosyaEkle_Click(object? sender, RoutedEventArgs e)
    {
        var topLevel = TopLevel.GetTopLevel(this);
        if (topLevel == null) return;

        var secilenDosyalar = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Nota Eklenecek Dosyayı Seç",
            AllowMultiple = false
        });

        if (secilenDosyalar.Count > 0)
        {
            string kaynakYol = secilenDosyalar[0].Path.LocalPath;
            string dosyaAdi = Path.GetFileName(kaynakYol);
            string hedefYol = Path.Combine(_eklerKlasoru, dosyaAdi);

            File.Copy(kaynakYol, hedefYol, overwrite: true);

            if (!_aktifNot.EkliDosyalar.Contains(dosyaAdi))
            {
                _aktifNot.EkliDosyalar.Add(dosyaAdi);
                EklerListesi.ItemsSource = _aktifNot.EkliDosyalar.ToList();
            }
        }
    }

    private void DosyaAc_Click(object? sender, RoutedEventArgs e)
    {
        if (EklerListesi.SelectedItem is not string dosyaAdi) return;

        string tamYol = Path.Combine(_eklerKlasoru, dosyaAdi);
        if (File.Exists(tamYol))
        {
            Process.Start(new ProcessStartInfo(tamYol) { UseShellExecute = true });
        }
    }

    // Sağ listeden seçili ek dosyayı nottan ve Ekler klasöründen siler
    private void DosyaSil_Click(object? sender, RoutedEventArgs e)
    {
        if (EklerListesi.SelectedItem is not string dosyaAdi) return;

        _aktifNot.EkliDosyalar.Remove(dosyaAdi);
        EklerListesi.ItemsSource = _aktifNot.EkliDosyalar.ToList();

        string tamYol = Path.Combine(_eklerKlasoru, dosyaAdi);
        if (File.Exists(tamYol))
        {
            File.Delete(tamYol);
        }

        // Not zaten kayıtlıysa güncel ek listesini JSON dosyasına da kaydet
        if (!string.IsNullOrWhiteSpace(_aktifNot.Baslik))
        {
            string jsonYolu = Path.Combine(_anaKlasor, $"{_aktifNot.Baslik}.json");
            if (File.Exists(jsonYolu))
            {
                string jsonMetni = JsonSerializer.Serialize(_aktifNot, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(jsonYolu, jsonMetni);
            }
        }
    }
}